# Vue JS | Dynamic editable table ( with add, remove and editing row and cell )

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pizzi/pen/GMOQXy](https://codepen.io/Pizzi/pen/GMOQXy).

Simple VUE JS application, that allow manage little table.
In this example, you can edit table title, and every single cell.
You can add or remove rows, once a row it' s added , you can edit it by clicking "editing" button. 